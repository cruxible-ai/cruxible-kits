"""Support library for Cruxible provider packages.

A provider is one Python package with its own committed lock, a package-side
manifest, a registration declaring its typed operations (the capabilities each
serves, and copies of the shapes each accepts and returns), and one or more
entrypoints serving them. This library is what makes such a package bindable: it
owns the manifest, registration and protocol schemas (protocol 2.0: a run names
one operation of one build), both identity digests, lock resolution, the
pinned-index artifact fetcher an explicit install materializes environments
with, the materialization cache, secret delivery, budget enforcement, egress
instrumentation, and the runtime's own closed refusal codes that keep every path
fail-closed.

It does **not** own governance. The Provider build artifact, the capabilities,
the fit of an operation to a slot, and Line bindings live in core; this package ships schemas and
a conformance harness against a stub registry. See
``docs/core-integration-seam.md``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .artifact import ProviderArtifactPayload, artifact_digest, load_provider_artifact
from .backends import MaterializationRequest, UvSyncBuilder, verify_environment
from .binding import Binding, BindRequest, bind
from .budget import ProcessOutcome, enforce_cost_budget, run_with_budget
from .cache import MaterializationCache
from .canonical import canonical_json, domain_digest

# dependency_closure_digest and CLOSURE_DOMAIN_TAG are deliberately NOT
# re-exported here. They belong to the packaging-scope gate, not to identity: a
# core executor importing this package should see exactly two digest functions,
# because a third one sitting beside them invites someone to pin a track record
# to it. The gate imports them from cruxible_provider_runtime.digests directly.
from .digests import (
    IMPLEMENTATION_DOMAIN_TAG,
    MATERIALIZATION_DOMAIN_TAG,
    implementation_digest,
    materialization_digest,
)
from .egress import (
    DYNAMIC_ENDPOINT_FORMS,
    DYNAMIC_TARGET_FROM_RUN_INPUT,
    EgressRecorder,
    compare_egress,
    enforce_egress,
    write_child_guard,
)
from .errors import (
    Declined,
    ProviderErrorPayload,
    Refusal,
    RefusalCode,
    RefusalError,
    decline,
)
from .execute import InvocationOutcome, invoke
from .index import ArtifactFetcher, IndexConfig
from .manifest import ProviderManifest, load_manifest, manifest_digest
from .operations import ContractRef, ProviderOperation, operation_signature_digest
from .protocol import PROTOCOL_VERSION, Budgets, ResultEnvelope, RunContext
from .provider_api import Provider, ProviderResult, ProviderRunContext, ProviderStatus
from .registration import (
    ProviderDeclares,
    RegistrationBundle,
    load_registration,
    write_registration,
)
from .registry import AcceptedBuild, StubRegistry
from .resolution import (
    MarkerEnvironment,
    ResolvedSet,
    environment_pin_key,
    load_uv_lock,
    resolve,
)

if TYPE_CHECKING:  # pragma: no cover - resolved lazily at runtime, see __getattr__
    from .container_entry import SECRET_CHANNEL_FD, container_secret_channel

__version__ = "0.5.0"

__all__ = [
    "DYNAMIC_ENDPOINT_FORMS",
    "DYNAMIC_TARGET_FROM_RUN_INPUT",
    "IMPLEMENTATION_DOMAIN_TAG",
    "MATERIALIZATION_DOMAIN_TAG",
    "PROTOCOL_VERSION",
    "SECRET_CHANNEL_FD",
    "AcceptedBuild",
    "ArtifactFetcher",
    "BindRequest",
    "Binding",
    "Budgets",
    "ContractRef",
    "Declined",
    "EgressRecorder",
    "IndexConfig",
    "InvocationOutcome",
    "MarkerEnvironment",
    "MaterializationCache",
    "MaterializationRequest",
    "ProcessOutcome",
    "Provider",
    "ProviderArtifactPayload",
    "ProviderDeclares",
    "ProviderErrorPayload",
    "ProviderManifest",
    "ProviderOperation",
    "ProviderResult",
    "ProviderRunContext",
    "ProviderStatus",
    "Refusal",
    "RefusalCode",
    "RefusalError",
    "RegistrationBundle",
    "ResolvedSet",
    "ResultEnvelope",
    "RunContext",
    "StubRegistry",
    "UvSyncBuilder",
    "__version__",
    "artifact_digest",
    "bind",
    "canonical_json",
    "compare_egress",
    "container_secret_channel",
    "decline",
    "domain_digest",
    "enforce_cost_budget",
    "enforce_egress",
    "environment_pin_key",
    "implementation_digest",
    "invoke",
    "load_manifest",
    "load_provider_artifact",
    "load_registration",
    "load_uv_lock",
    "manifest_digest",
    "materialization_digest",
    "operation_signature_digest",
    "resolve",
    "run_with_budget",
    "verify_environment",
    "write_child_guard",
    "write_registration",
]

_SHIM_EXPORTS = frozenset({"SECRET_CHANNEL_FD", "container_secret_channel"})


def __getattr__(name: str) -> Any:
    """Resolve the container-shim exports without importing the shim module.

    Both names live in :mod:`cruxible_provider_runtime.container_entry`, which
    is also the module the provider images run as ``__main__``. Importing it
    here eagerly put it in ``sys.modules`` before ``runpy`` executed it, and
    ``runpy`` answers that with a ``RuntimeWarning`` on stderr: 232 bytes on
    every containerised run, billed against the run's ``output_bytes`` budget —
    which is aggregate over stdout and stderr — and a permanent line in every
    run's trace, from the one module whose promise is that the child sees
    exactly the process it saw before the shim existed.

    Resolving lazily keeps the export and drops the double import. An executor
    that reads either name pays the import at that point, which is what it was
    always going to pay.
    """

    if name in _SHIM_EXPORTS:
        from . import container_entry

        return getattr(container_entry, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
