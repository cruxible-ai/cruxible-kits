"""The package-side provider manifest.

The manifest ships inside the provider distribution and declares, per
implementation — one row per **entrypoint** object path — the backend kinds it
runs under, the external endpoints it contacts, the per-engine extras its
environment needs, and whether it is deterministic.

What an implementation *serves* is not here. The package's ``registration.json``
declares its typed operations, each naming the entrypoint that serves it; an
entrypoint may serve several. The operation's ``effect`` is the one declaration
of whether it mutates the world, so the manifest no longer repeats it.

**The package-side manifest is never authority.** It is a transcription source;
authority is the accepted ``providers/<provider-id>.yaml`` governed artifact.
At bind and invoke the runtime recomputes this manifest's digest and refuses on
any divergence from the accepted artifact.

Unknown fields fail closed: every model here forbids extras, and
:func:`load_manifest` converts the resulting validation error into a typed
``unknown_manifest_field`` refusal.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

from .canonical import domain_digest
from .egress import DYNAMIC_ENDPOINT_FORMS, normalize_endpoint
from .errors import RefusalCode, RefusalError, refuse

__all__ = [
    "ENTRYPOINT_GROUP",
    "MANIFEST_DOMAIN_TAG",
    "BackendKind",
    "DistributionRef",
    "ImplementationManifest",
    "ProviderManifest",
    "load_manifest",
    "load_manifest_document",
    "manifest_digest",
]

MANIFEST_DOMAIN_TAG = "cruxible.provider.manifest.v1"
ENTRYPOINT_GROUP = "cruxible.providers"

BackendKind = Literal["local_env", "container"]


class DistributionRef(BaseModel):
    """Names the distribution this manifest belongs to.

    The distribution's own sha256 is deliberately absent: a manifest shipped
    inside an artifact cannot contain that artifact's hash. The hash is carried
    by the accepted Provider artifact and is what the implementation digest
    consumes.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    name: str
    version: str


class ImplementationManifest(BaseModel):
    """One entrypoint inside a provider package: how and where it runs."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    entrypoint: str = Field(description="module path and object, e.g. 'pkg.mod:Object'")
    backends: tuple[BackendKind, ...]
    declared_endpoints: tuple[str, ...] = ()
    requires_extras: tuple[str, ...] = ()
    """The package extras this implementation's environment must carry.

    Heavy engines — a browser, a document-conversion stack, an OCR runtime —
    live behind per-engine extras so that the base distribution stays light and
    the default conformance lane installs no engine at all. An implementation
    that needs one says so here, and the extras it names are what the resolver
    is asked for when the environment is materialized. Two implementations in
    one package may therefore require different extras and bind to different
    environments from the same lock.
    """

    deterministic: bool

    @field_validator("requires_extras")
    @classmethod
    def _extras_are_named_once(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        if len(set(value)) != len(value):
            raise ValueError(f"duplicate extras: {value}")
        for extra in value:
            if not extra or extra.strip() != extra:
                raise ValueError(f"invalid extra name: {extra!r}")
        return value

    @field_validator("declared_endpoints")
    @classmethod
    def _endpoints_are_endpoints_or_known_dynamic_forms(
        cls, value: tuple[str, ...]
    ) -> tuple[str, ...]:
        """Fail closed on an endpoint declaration nothing can interpret.

        Two spellings are legal: a concrete ``scheme://host[:port]``, and one of
        the EXPERIMENTAL dynamic forms for an adapter whose target is decided by
        the run input. An unrecognised ``dynamic:`` form is refused rather than
        treated as a hostname — reading ``dynamic:whatever-comes-next`` as a
        host named ``dynamic`` would turn a declaration nobody understands into
        a declaration that quietly matches nothing.
        """

        for entry in value:
            if entry in DYNAMIC_ENDPOINT_FORMS:
                continue
            if entry.startswith("dynamic:"):
                raise ValueError(
                    f"unknown dynamic endpoint form {entry!r}; known forms are "
                    f"{sorted(DYNAMIC_ENDPOINT_FORMS)}"
                )
            try:
                normalize_endpoint(entry)
            except RefusalError as exc:
                raise ValueError(f"declared endpoint {entry!r} is not an endpoint") from exc
        return value

    @field_validator("entrypoint")
    @classmethod
    def _object_path(cls, value: str) -> str:
        module, sep, obj = value.partition(":")
        if not sep or not module or not obj:
            raise ValueError(f"entrypoint must be 'module:object', got {value!r}")
        return value

    @field_validator("backends")
    @classmethod
    def _backends_non_empty(cls, value: tuple[BackendKind, ...]) -> tuple[BackendKind, ...]:
        if not value:
            raise ValueError("an implementation must declare at least one backend kind")
        if len(set(value)) != len(value):
            raise ValueError(f"duplicate backend kinds: {value}")
        return value


class ProviderManifest(BaseModel):
    """The whole package-side manifest."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal[2] = 2
    provider_id: str
    distribution: DistributionRef
    entrypoint_group: Literal["cruxible.providers"] = "cruxible.providers"
    supported_protocol_majors: tuple[int, ...]
    implementations: tuple[ImplementationManifest, ...]

    @field_validator("supported_protocol_majors")
    @classmethod
    def _majors_non_empty(cls, value: tuple[int, ...]) -> tuple[int, ...]:
        if not value:
            raise ValueError("a manifest must declare at least one supported protocol major")
        return value

    @field_validator("implementations")
    @classmethod
    def _implementations_unique(
        cls, value: tuple[ImplementationManifest, ...]
    ) -> tuple[ImplementationManifest, ...]:
        if not value:
            raise ValueError("a manifest must declare at least one implementation")
        entrypoints = [impl.entrypoint for impl in value]
        if len(set(entrypoints)) != len(entrypoints):
            raise ValueError(f"each implementation has its own entrypoint: {entrypoints}")
        return value

    def implementation(self, entrypoint: str) -> ImplementationManifest:
        """The implementation row for ``entrypoint``, or a divergence refusal.

        An operation names its entrypoint in the registration; a manifest
        without that row is a package whose two declarations disagree.
        """

        for impl in self.implementations:
            if impl.entrypoint == entrypoint:
                return impl
        raise refuse(
            RefusalCode.MANIFEST_DIVERGENCE,
            f"provider {self.provider_id!r} declares no implementation at {entrypoint!r}",
            provider_id=self.provider_id,
            entrypoint=entrypoint,
            declared=[impl.entrypoint for impl in self.implementations],
        )

    def canonical_payload(self) -> dict[str, Any]:
        """The manifest as a plain JSON-able mapping, for digesting/transcription."""

        document: dict[str, Any] = json.loads(self.model_dump_json())
        return document


def manifest_digest(manifest: ProviderManifest) -> str:
    """Digest a manifest under ``cruxible.provider.manifest.v1``."""

    return domain_digest(MANIFEST_DOMAIN_TAG, manifest.canonical_payload())


def load_manifest_document(document: Any) -> ProviderManifest:
    """Validate an already-parsed manifest document, failing closed on extras.

    Only schema 2 is read. A schema-1 manifest keyed its rows by interface and
    claimed input buckets; it is refused as such, not field by field.
    """

    if isinstance(document, dict) and document.get("schema_version", 2) != 2:
        raise refuse(
            RefusalCode.UNKNOWN_MANIFEST_FIELD,
            f"manifest schema {document.get('schema_version')!r} is not read; a schema-2 "
            "manifest keys implementations by entrypoint and the registration declares "
            "the operations they serve",
            schema_version=document.get("schema_version"),
        )
    try:
        return ProviderManifest.model_validate(document)
    except ValidationError as exc:
        extras = [
            ".".join(str(part) for part in error["loc"])
            for error in exc.errors()
            if error["type"] == "extra_forbidden"
        ]
        if extras:
            raise refuse(
                RefusalCode.UNKNOWN_MANIFEST_FIELD,
                f"manifest declares unknown fields: {extras}",
                fields=extras,
            ) from exc
        raise refuse(
            RefusalCode.UNKNOWN_MANIFEST_FIELD,
            "manifest failed schema validation",
            errors=json.loads(exc.json()),
        ) from exc


def load_manifest(path: Path) -> ProviderManifest:
    """Load and validate a manifest from a YAML or JSON file."""

    text = path.read_text(encoding="utf-8")
    document = yaml.safe_load(text)
    if not isinstance(document, dict):
        raise refuse(
            RefusalCode.UNKNOWN_MANIFEST_FIELD,
            f"manifest at {path} is not a mapping",
            path=str(path),
        )
    return load_manifest_document(document)
