"""The invocation protocol: run context in, result envelope out.

``protocol_version`` is ``major.minor`` and governs the transport *envelope*.
The operation's Contracts govern its input, output and refusal *schema*, and
the run context names them only by the operation and its signature digest. The
two are independent axes and neither is derivable from the other.

Protocol 2.0 runs one **operation** of one provider **build**. The run context
names the operation (``operation``), the exact ``{in, out, effect}`` signature
it was bound under (``operation_signature_digest``) and the accepted build
(``build_digest``); the entrypoint it dispatches to serves that operation. There
is no interface and no input bucket in 2.0, and a 1.x context is refused.

Versioning rules:

* the manifest declares the protocol majors it supports;
* bind refuses an unsupported or absent major (``unsupported_protocol``);
* a run context or result envelope at any other major refuses
  ``unsupported_protocol`` before anything else in it is read, so a 1.x
  context is reported as the version mismatch it is, never as a pile of
  unknown fields;
* minor is additive-only — a provider ignores unknown additive run-context
  fields within its major, and refuses unknown fields outside the additive
  region (``unknown_run_context_field``).

The additive region is the explicit ``additive`` mapping. Everything else in the
envelope is closed, so "additive-only" is a structural property rather than a
promise to be careful.

**Nothing non-finite leaves a provider as a success.** A NaN or an infinity
anywhere inside a result envelope refuses, recursively, at this layer. It is a
protocol rule rather than a numerical one: canonical JSON has no spelling for
either value, so a NaN in an output is a value no receipt can record and no
digest can cover, whatever the implementation meant by it. Each plane still owes
its own domain check — a degenerate sample deserves a decline that says so, not
a generic one — and this is the floor underneath all of them.
"""

from __future__ import annotations

import json
import math
import re
from collections.abc import Iterator, Mapping
from typing import Any, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

from .canonical import SHA256_RE
from .errors import ProviderErrorPayload, Refusal, RefusalCode, refuse

__all__ = [
    "OPERATION_NAME_RE",
    "PROTOCOL_VERSION",
    "Budgets",
    "ProtocolVersion",
    "ResultEnvelope",
    "RunContext",
    "SecretChannelSpec",
    "SecretRef",
    "Trace",
    "Unencodable",
    "parse_result_envelope",
    "parse_run_context",
    "reject_non_finite",
    "require_supported_major",
]

OPERATION_NAME_RE = re.compile(r"^[a-z][a-z0-9_.-]{0,255}$")
"""An operation name: the spelling core's ``ProviderOperation`` accepts."""

_MAX_REPORTED_PATHS = 10


class Unencodable:
    """Stands in for a value no JSON type holds, copied out of provider code.

    The child harness copies a provider's result into plain JSON types before
    any check reads it, so that no provider-defined method runs outside the
    guard around provider code. A value it cannot copy is replaced by this,
    carrying only the original type's name, and refused here exactly as the
    original would have been.
    """

    __slots__ = ("type_name",)

    def __init__(self, type_name: str) -> None:
        self.type_name = type_name


def _type_name(value: Any) -> str:
    return value.type_name if type(value) is Unencodable else type(value).__name__


def _walk(value: Any, path: str) -> Iterator[tuple[str, str]]:
    """Yield ``(kind, path)`` for everything inside ``value`` an envelope cannot carry.

    Three kinds, because they are distinct faults. ``non_finite`` is a number
    with no JSON spelling. ``non_string_key`` is a mapping key the serialiser
    would have to reinterpret. ``unsupported`` is a value this walk will not
    descend into and will not vouch for — and it has to be a fault rather than a
    shrug, because a walk that silently skips what it does not recognise is a
    walk whose "no NaN here" means "no NaN in the parts I understood". Each of
    the three ways that failed is a different kind of quiet: a ``set`` holding a
    NaN serialises to ``null`` and loses it, a ``Decimal('NaN')`` serialises to
    the *string* ``"NaN"`` and reads as data, and a ``numpy.float32`` reaches the
    serialiser and raises there, past every typed refusal this module owns.
    """

    if value is None or isinstance(value, (bool, int, str)):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            yield ("non_finite", path or "<root>")
        return
    if isinstance(value, Mapping):
        for index, (key, item) in enumerate(value.items()):
            if not isinstance(key, str):
                prefix = f"{path}." if path else ""
                yield ("non_string_key", f"{prefix}<key[{index}]> ({_type_name(key)})")
                yield from _walk(item, f"{prefix}<value[{index}]>")
                continue
            yield from _walk(item, f"{path}.{key}" if path else key)
        return
    if isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            yield from _walk(item, f"{path}[{index}]")
        return
    yield ("unsupported", f"{path or '<root>'} ({_type_name(value)})")


def reject_non_finite(value: Any, *, where: str) -> None:
    """Refuse a payload an envelope cannot carry, from anywhere inside it.

    The walk is recursive because the shallow version of this check is the one
    that passes: a NaN is almost never at the top of an output, it is the third
    element of an interval inside a list of forecasts.

    It is also **closed** over the JSON types rather than open over them. An
    output is on its way to canonical JSON, so a value outside ``None``,
    ``bool``, ``int``, ``float``, ``str`` and the two containers, or a mapping
    key that is not a string, is not one with a subtler encoding — it is one
    whose encoding this layer would be guessing at, and every available guess
    is worse than the refusal.
    """

    findings = sorted(set(_walk(value, "")))
    non_finite = [path for kind, path in findings if kind == "non_finite"]
    if non_finite:
        raise refuse(
            RefusalCode.NON_FINITE_OUTPUT,
            f"{where} carries a non-finite number, which canonical JSON cannot represent",
            where=where,
            paths=non_finite[:_MAX_REPORTED_PATHS],
            count=len(non_finite),
        )
    unsupported = [path for kind, path in findings if kind in {"non_string_key", "unsupported"}]
    if unsupported:
        raise refuse(
            RefusalCode.PROVIDER_PROTOCOL_VIOLATION,
            f"{where} carries a value or mapping key canonical JSON has no encoding for",
            where=where,
            paths=unsupported[:_MAX_REPORTED_PATHS],
            count=len(unsupported),
        )


def _reject_non_string_keys(value: Any, *, where: str) -> None:
    """Refuse raw mapping keys before schema validation can reinterpret them."""

    findings = sorted(set(_walk(value, "")))
    paths = [path for kind, path in findings if kind == "non_string_key"]
    if paths:
        raise refuse(
            RefusalCode.PROVIDER_PROTOCOL_VIOLATION,
            f"{where} carries a mapping key canonical JSON has no encoding for",
            where=where,
            paths=paths[:_MAX_REPORTED_PATHS],
            count=len(paths),
        )


class ProtocolVersion(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    major: int
    minor: int

    @classmethod
    def parse(cls, value: str) -> ProtocolVersion:
        major, _, minor = value.partition(".")
        try:
            return cls(major=int(major), minor=int(minor))
        except ValueError as exc:
            raise refuse(
                RefusalCode.UNSUPPORTED_PROTOCOL,
                f"protocol version {value!r} is not major.minor",
                protocol_version=value,
            ) from exc

    def render(self) -> str:
        return f"{self.major}.{self.minor}"


PROTOCOL_VERSION = ProtocolVersion(major=2, minor=0)
"""The protocol version this runtime speaks."""


def require_supported_major(value: str, *, where: str) -> ProtocolVersion:
    """Parse ``value`` and refuse any major other than :data:`PROTOCOL_VERSION`'s."""

    requested = ProtocolVersion.parse(value)
    if requested.major != PROTOCOL_VERSION.major:
        raise refuse(
            RefusalCode.UNSUPPORTED_PROTOCOL,
            f"{where} is protocol {value}; this runtime speaks {PROTOCOL_VERSION.render()}",
            supported_major=PROTOCOL_VERSION.major,
            requested=value,
        )
    return requested


class Budgets(BaseModel):
    """Caps the executor enforces out-of-process.

    ``cost_units`` travels with the run so a provider can report against it, but
    RP-0 enforces only the two caps it can enforce locally: wall clock and output
    size. Cost enforcement belongs to the metering substrate.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    wall_clock_seconds: float
    output_bytes: int
    cost_units: float | None = None

    @field_validator("wall_clock_seconds")
    @classmethod
    def _positive_time(cls, value: float) -> float:
        if value <= 0:
            raise ValueError("wall_clock_seconds must be positive")
        return value

    @field_validator("output_bytes")
    @classmethod
    def _positive_size(cls, value: int) -> int:
        if value <= 0:
            raise ValueError("output_bytes must be positive")
        return value


class SecretRef(BaseModel):
    """Names a credential without carrying it.

    Only the ref travels in the serialised run context. The material arrives
    separately over the inherited descriptor named by :class:`SecretChannelSpec`.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    ref: str
    purpose: str = ""


class SecretChannelSpec(BaseModel):
    """Where the provider process reads credential material from."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal["fd"] = "fd"
    fd: int
    refs: tuple[SecretRef, ...] = ()

    @field_validator("fd")
    @classmethod
    def _not_standard_stream(cls, value: int) -> int:
        if value <= 2:
            raise ValueError("the secret channel must not reuse a standard stream")
        return value


def _sha256(value: str) -> str:
    if not SHA256_RE.match(value):
        raise ValueError(f"expected a sha256:<hex> digest, got {value!r}")
    return value


class RunContext(BaseModel):
    """Everything the executor passes into a provider process.

    ``operation`` is the one operation this run executes, by name;
    ``operation_signature_digest`` is the exact ``{in, out, effect}`` signature
    the Line bound it under; ``build_digest`` is the accepted provider build.
    ``entrypoint`` is the object the child dispatches to, and it must declare
    ``operation`` among the operations it serves.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    protocol_version: str
    run_id: str
    operation: str
    operation_signature_digest: str
    build_digest: str
    implementation_digest: str
    entrypoint: str
    coordinates: dict[str, Any] = Field(default_factory=dict)
    input: dict[str, Any] = Field(default_factory=dict)
    capture_contract: str | None = None
    budgets: Budgets
    declared_endpoints: tuple[str, ...] = ()
    secret_channel: SecretChannelSpec | None = None
    additive: dict[str, Any] = Field(
        default_factory=dict,
        description="the additive region: unknown keys here are ignored by a provider",
    )

    @model_validator(mode="before")
    @classmethod
    def _closed_mapping_keys(cls, value: Any) -> Any:
        _reject_non_string_keys(value, where="provider run context")
        return value

    _digests = field_validator(
        "operation_signature_digest", "build_digest", "implementation_digest"
    )(_sha256)

    @field_validator("operation")
    @classmethod
    def _operation_name(cls, value: str) -> str:
        if not OPERATION_NAME_RE.fullmatch(value):
            raise ValueError(f"operation {value!r} is not a canonical operation name")
        return value

    @model_validator(mode="after")
    def _version_shape(self) -> Self:
        require_supported_major(self.protocol_version, where="the run context")
        return self

    def to_json(self) -> bytes:
        return self.model_dump_json().encode("utf-8")


class Trace(BaseModel):
    """Trace material destined for exhaust.

    ``endpoints_contacted`` is what was *actually* contacted, recorded by the
    instrumented client locally and by the proxy log in cloud. It is compared
    against the accepted declaration; a contacted endpoint outside the
    declaration is a typed conformance violation attributed to the
    implementation digest.
    """

    model_config = ConfigDict(extra="forbid")

    endpoints_contacted: list[str] = Field(default_factory=list)
    events: list[dict[str, Any]] = Field(default_factory=list)
    metrics: dict[str, float] = Field(default_factory=dict)


class ResultEnvelope(BaseModel):
    """Everything a provider process returns."""

    model_config = ConfigDict(extra="forbid")

    protocol_version: str
    run_id: str
    status: Literal["ok", "refused", "error"]
    output: dict[str, Any] | None = None
    # The provider's own word that ``output`` is missing members: it names
    # out-Contract ``list<capture<...>>`` fields the provider could not fill
    # whole (a page it failed to fetch, say). Core treats each named field
    # exactly as a list it dropped a member from itself (D-R37 a4): the call
    # is incomplete, and absence over it never retires. It is generic: core
    # reads no provider- or operation-specific field to learn it. Only an ok
    # result carries it, and it is omitted when empty -- so existing vectors
    # round-trip byte-exactly. Kept off the class docstring deliberately: a
    # docstring becomes the JSON schema's "description" and core's vendored
    # fixture predates this explanation.
    incomplete_captures: list[str] = Field(default_factory=list, exclude_if=lambda value: not value)
    refusal: Refusal | None = None
    error: ProviderErrorPayload | None = None
    trace: Trace = Field(default_factory=Trace)

    @model_validator(mode="before")
    @classmethod
    def _closed_mapping_keys(cls, value: Any) -> Any:
        _reject_non_string_keys(value, where="provider result envelope")
        return value

    @model_validator(mode="after")
    def _status_consistency(self) -> Self:
        if self.status == "ok" and self.output is None:
            raise ValueError("an ok result must carry output")
        if self.status == "refused" and self.refusal is None:
            raise ValueError("a refused result must carry a refusal")
        if self.status == "error" and self.error is None:
            raise ValueError("an error result must carry an error")
        if self.status != "ok" and self.output is not None:
            raise ValueError("only an ok result may carry output")
        if self.status != "ok" and self.incomplete_captures:
            raise ValueError("only an ok result may name incomplete captures")
        require_supported_major(self.protocol_version, where="the result envelope")
        # A typed refusal rather than a ValueError, and therefore not wrapped
        # into a validation error: this is the runtime declining under a named
        # rule, and it must arrive at both ends -- the child cannot build such an
        # envelope, and the executor will not accept one built elsewhere. Nothing
        # gets past it into the serialiser either: the walk is closed over the
        # JSON types, so a value it does not recognise refuses here rather than
        # raising from model_dump_json with no refusal attached.
        reject_non_finite(self.output, where="provider output")
        reject_non_finite(self.trace.metrics, where="provider trace metrics")
        reject_non_finite(self.trace.events, where="provider trace events")
        if self.refusal is not None:
            reject_non_finite(self.refusal.detail, where="refusal detail")
        if self.error is not None:
            reject_non_finite(self.error.detail, where="provider error detail")
        return self

    def to_json(self) -> bytes:
        return self.model_dump_json().encode("utf-8")


def _extra_fields(exc: ValidationError) -> list[str]:
    return [
        ".".join(str(part) for part in error["loc"])
        for error in exc.errors()
        if error["type"] == "extra_forbidden"
    ]


def _version_first(document: Any, *, where: str) -> None:
    """Refuse another major before the strict schema reads anything else.

    A 1.x run context carries ``interface_id`` and ``input_bucket``; read
    against the 2.0 schema those are unknown fields, which is true and beside
    the point. The version is the fault, so it is the refusal.
    """

    if isinstance(document, Mapping):
        version = document.get("protocol_version")
        if isinstance(version, str):
            require_supported_major(version, where=where)


def parse_run_context(raw: bytes) -> RunContext:
    """Parse a run context on the provider side, failing closed on unknown fields."""

    try:
        document = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        raise refuse(
            RefusalCode.PROVIDER_PROTOCOL_VIOLATION,
            "run context is not valid UTF-8 JSON",
        ) from exc
    _version_first(document, where="the run context")
    try:
        return RunContext.model_validate(document)
    except ValidationError as exc:
        extras = _extra_fields(exc)
        if extras:
            raise refuse(
                RefusalCode.UNKNOWN_RUN_CONTEXT_FIELD,
                f"run context carries fields outside the additive region: {extras}",
                fields=extras,
            ) from exc
        raise refuse(
            RefusalCode.PROVIDER_PROTOCOL_VIOLATION,
            "run context failed schema validation",
            errors=json.loads(exc.json()),
        ) from exc


def parse_result_envelope(raw: bytes) -> ResultEnvelope:
    """Parse a result envelope on the executor side, failing closed."""

    try:
        document = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        raise refuse(
            RefusalCode.PROVIDER_PROTOCOL_VIOLATION,
            "provider did not return valid UTF-8 JSON",
            head=raw[:200].decode("utf-8", "replace"),
        ) from exc
    _version_first(document, where="the result envelope")
    try:
        return ResultEnvelope.model_validate(document)
    except ValidationError as exc:
        raise refuse(
            RefusalCode.PROVIDER_PROTOCOL_VIOLATION,
            "provider returned a malformed result envelope",
            errors=json.loads(exc.json()),
        ) from exc
